﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.KeyVault;
using System.Reflection;

namespace ConfigValidator
{
    class Validateconfigfile
    {
      
        static  Dictionary<string,string> allValues = new Dictionary<string, string>();
        static Dictionary<string, string> errorList = new Dictionary<string, string>();

     
        static void Main(string[] args)
        {
            var appSettings = ConfigurationManager.AppSettings;

            if (appSettings.Count == 0)
            {
                Console.WriteLine("AppSettings is empty.");

            }

            else
                    {
                int settingcount = 0;
                List<string> configSettings = new List<string>();
                for (settingcount = 0; settingcount < appSettings.Count; settingcount++)
                {
                    configSettings.Add(appSettings.AllKeys[settingcount]);
                }
                foreach (string setting1 in configSettings)
                {
                    try
                    {
                        string Value = LoadConfigurationsFromAzure(setting1);
                        if (!string.IsNullOrEmpty(Value))
                        {
                            allValues.Add(setting1, Value);
                         
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error :" + ex.Message);
                    }
                }
                foreach (KeyValuePair<string, string> item in allValues)
                {
                    Console.WriteLine("\n Key value: {0}  , Result: {1}", item.Key, item.Value);
                }
                if (errorList.Count > 0)
                {
                    Console.WriteLine("\n Issue in retrieving below values");

                    foreach (KeyValuePair<string, string> item in errorList)
                    {

                        Console.WriteLine("\n Key value: {0}", item.Key);

                    }
                }

                Console.WriteLine("Press any key to close this window...");
                Console.ReadKey();

            }
        }

        static string LoadConfigurationsFromAzure(string key)
        {
             MethodBase method = MethodBase.GetCurrentMethod();
            try
            {
                AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
                var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));

                string value = Task.Run(async () => await keyVaultClient.GetSecretAsync(ConfigurationManager.AppSettings[key])).Result.Value;
                return value;
            }
            catch (Exception ex) {
                errorList.Add(key, ex.Message);
               // Console.WriteLine("Error in retrieving Key {0} from Keyvault" + key);
               // Console.WriteLine(ex.Message);
                return null;
            }
            
        }
    }
}
